﻿using Google.Cloud.Firestore;

namespace Synoptic.Models
{
    public class Menu
    {
        public int Order { get; set; }
        public string Title { get; set; }
        public string Link { get; set; }
        [FirestoreProperty]
        public string ImageBase64 { get; set; }
        public string Id { get; set; }
        public string Hidden { get; set; }
    }
}
