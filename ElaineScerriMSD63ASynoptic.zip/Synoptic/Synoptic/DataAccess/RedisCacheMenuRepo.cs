﻿using Newtonsoft.Json;
using StackExchange.Redis;
using Synoptic.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Synoptic.DataAccess
{
    public class RedisCacheMenuRepo
    {
        IDatabase myCacheDB;

        public RedisCacheMenuRepo(string connection)
        {
            var cn = ConnectionMultiplexer.Connect(connection);
            myCacheDB = cn.GetDatabase();
        }

        public async void AddMenu(Menu m)
        {
            var list = await GetMenus();
            list.Add(m);
            string menus = JsonConvert.SerializeObject(list);
            await myCacheDB.StringSetAsync("menus", menus);
        }

        public async Task<List<Menu>> GetMenus()
        {

            string menus = await myCacheDB.StringGetAsync("menus");
            var list = JsonConvert.DeserializeObject<List<Menu>>(menus);
            return list;
        }

        public void HideMenu(int id)
        {

        }
    }
}
