﻿using Google.Cloud.Storage.V1;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Synoptic.Models;
using System;

namespace Synoptic.Controllers
{
    public class MenuController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]

        public IActionResult Create(Menu m, IFormFile image) 
        {
            try
            {
                string imagename;
                if(image !=null)
                {
                    var storage = StorageClient.Create();
                    using var imagestream = image.OpenReadStream();
                    imagename = Guid.NewGuid().ToString() + System.IO.Path.GetExtension(image.FileName);

                    storage.UploadObject("synopticbucket1", imagename, null, imagestream);

                    m.Link = $"https://storage.googlesapis.com/{"synopticbucket1"}/{imagename}";
                }
                TempData["success"] = "menu was added successfully";
            }
            catch
            {

                TempData["error"] = "menu was not added successfully";
            }
            return View();
        }
    }
}
